<?php
/**
 * @package MegaMain
 * @subpackage MegaMain
 * @since mm 1.0
 */
	if ( is_admin() ) {
		include_once( 'array_theme_options.php' );
	}
?>