<?php
/**
 * @package MegaMain
 * @subpackage MegaMain
 * @since mm 1.0
 */
	if( is_admin() ) {
		include_once( 'icons_modal.php' );
		include_once( 'backup_settings.php' );
	}

?>